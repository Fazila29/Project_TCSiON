package com.tcs.constants;

public class AutomationConstants {
	public static final String CFURL ="https://phptravels.com/demo/";
	public static final String CFURL1 ="https://www.phptravels.net/account/dashboard";
	public static final String CFURL2 ="https://www.phptravels.net/login/failed";
	public static final String CFURL3="https://www.phptravels.net/account/bookings";
	public static final String CFURL4="https://www.phptravels.net/hotels/booking/invoice/4718/185";
	public static final String CFURL5="https://www.phptravels.net/account/add_funds";
	public static final String CFURL6="https://www.phptravels.net/payment/paypal";
	public static final String CFURL9="https://www.phptravels.net/login";
	public static final String CFURL7="https://www.phptravels.net/account/profile";
	public static final String CFURL8="https://www.phptravels.net/account/profile/success";
	public static final String CFAFURL="https://www.phptravels.net/login";
	public static final String CFURL10="https://www.phptravels.net/account/funds-success";
		
	public static final String PPEMAIL="sb-itxir5994130@personal.example.com";
	public static final String PPPASSWORD="testpayment";
	
	public static final String AFURL13="https://www.phptravels.net/login/failed";
	public static final String AFURL1="https://www.phptravels.net/account/dashboard";
	public static final String AFURL2="https://www.phptravels.net/account/bookings";
	public static final String AFURL3="https://www.phptravels.net/account/add_funds";
	public static final String AFURL4="https://www.phptravels.net/account/profile";
	public static final String AFURL5="https://www.phptravels.net/";
	public static final String AFURL6="https://www.phptravels.net/hotels";
	public static final String AFURL7="https://www.phptravels.net/flights";
	public static final String AFURL8="https://www.phptravels.net/tours";
	public static final String AFURL9="https://www.phptravels.net/visa";
	public static final String AFURL10="https://www.phptravels.net/blog";
	public static final String AFURL11="https://www.phptravels.net/offers";
	public static final String AFURL12="https://www.phptravels.net/login";
	public static final String AFURL14="https://www.phptravels.net/hotels/en/usd/dubai/02-05-2022/03-05-2022/1/2/0/US";
	
	
	
	public static final String ADURL1="https://www.phptravels.net/api/admin";
	public static final String ADURL2="https://www.phptravels.net/api/admin";
	public static final String ADURL3="https://www.phptravels.net/api/admin/bookings";
	public static final String ADURL4="https://www.phptravels.net/";
	public static final String ADURL5="https://www.phptravels.net/flights/booking/invoice/8106/1";
	
	
	
	public static final String SBURL1="https://www.phptravels.net/api/supplier";
	public static final String SBURL2="https://www.phptravels.net/";
	public static final String SBURL3="https://www.phptravels.net/api/supplier/tours";
	public static final String SBURL4="https://www.phptravels.net/visa";
	public static final String SBURL5="https://www.phptravels.net/flights";
	public static final String SBURL6="https://www.phptravels.net/api/supplier/bookings";
	
	
	
	public static final String TXT1 ="Please fill out this field.";	
	public static final String TXT2="Wrong credentials,try again!";
	public static final String TXT3="Hotel Invoice-PHP TRAVELS";
	public static final String SBTXT1="Dashboard";
}
