package com.tcs.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.tcs.constants.AutomationConstants;
import com.tcs.pages.Agent;
import com.tcs.pages.CFLogin;
import com.tcs.utilities.ExcelUtility;

public class TCAgent extends TestBase {
	CFLogin objCFLogin;
	Agent objAgent;
	

	@Test(priority=1)
    public void TC_Af_001_verifyAgentLink() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
    objCFLogin= new CFLogin(driver);
    objAgent= new Agent(driver);
    objAgent.clickAgentLink();
    Thread.sleep(2000);
    for(String winHandle :driver.getWindowHandles())
    {
    	driver.switchTo().window(winHandle);
    }
    
    String expectedURL =AutomationConstants.CFAFURL;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent front end Login Page Opened,TC_Af_001 Passed");
      Thread.sleep(2000);   
	}

@Test(priority=2) //Invalid login with both fields blank
    public void TC_Af_002_verifyAgentInvalidLogin1() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
objAgent= new Agent(driver);	
objCFLogin= new CFLogin(driver);
objAgent.clearEmail();
objAgent.clearPassword();
Thread.sleep(2000);   
objAgent.clickLogin();
Thread.sleep(2000);

String validationMessage = objAgent.getEmail().getAttribute("validationMessage");	
String ExpectedValidation= AutomationConstants.TXT1;	
Assert.assertEquals(ExpectedValidation,validationMessage);
System.out.println("Login Failed, TC_Af_002 Passed");

	}
	
	@Test(priority=3) //Verify invalid login with valid email and invalid password
    public void TC_Af_003_verifyAgentInvalidLogin2() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
    objAgent= new Agent(driver);
	
  String email = ExcelUtility.getCellData(1,1);
    String password = ExcelUtility.getCellData(4,1);
       objCFLogin.setEmail(email);
       objCFLogin.setPassword(password);
       Thread.sleep(2000);
       objCFLogin.clickLogin();	
       Thread.sleep(3000);
       
       String expectedURL =AutomationConstants.AFURL13;
       String actualURL =driver.getCurrentUrl();
       Assert.assertEquals(expectedURL,actualURL);
       System.out.println("Login failed ,TC_Af_003 passed ");
       driver.navigate().back();
	
       Thread.sleep(2000);
	}
	

	@Test(priority=4)//Verify invalid login with valid email and null password
	public void TC_Af_004_verifyAgentInvalidLogin3() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		    //Create Login Page object
		    objAgent= new Agent(driver);
			objCFLogin.clearEmail();
		  String email = ExcelUtility.getCellData(1,1);
		  objCFLogin.setEmail(email);
		  objCFLogin.clearPassword();
		       objCFLogin.clickLogin();
		       Thread.sleep(2000);
		     //Assert popupmessage
		     //Capturing Validation Message and verifying.    
		       
		       
		       String validationMessage = objCFLogin.getPassword().getAttribute("validationMessage");	
		       String ExpectedValidation= AutomationConstants.TXT1;		
		       Assert.assertEquals(ExpectedValidation,validationMessage);
		       System.out.println("Login Failed, TC_Af_004 Passed");
		       	}
	
	@Test(priority=5)//	Verify invalid login with invalid email and valid password
	 public void TC_Af_005_verifyAgentInvalidLogin4() throws IOException, Exception {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
			    //Create Login Page object
			    objAgent= new Agent(driver);
			    //login to application
			  
			    objCFLogin.clearEmail();
			    String email = ExcelUtility.getCellData(3,1);
			    objCFLogin.clearPassword();
			   String password = ExcelUtility.getCellData(2,1);
			    objCFLogin.setEmail(email);
			  objCFLogin.setPassword(password);
			  Thread.sleep(1000);

			  objCFLogin.clickLogin();
			  String expectedURL =AutomationConstants.AFURL13;
		       String actualURL =driver.getCurrentUrl();
		       Assert.assertEquals(expectedURL,actualURL);
		       System.out.println("Login failed ,TC_Af_005 passed ");
		       driver.navigate().back();
			  Thread.sleep(2000);
		}
	
	@Test(priority=6)//Verify invalid login with blank email and valid password
	
	 public void TC_Af_006_verifyAgentInvalidLogin5() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		    //Create Login Page object
		    objCFLogin= new CFLogin(driver);
		    //login to application
		    
		   //objCFLogin.clickCFLink();
		    objCFLogin.clearEmail();
		    objCFLogin.clearPassword();
		    String password = ExcelUtility.getCellData(2,1);
		    objCFLogin.setPassword(password);
		    objCFLogin.clickLogin();
		  //Capturing Validation Message and verifying.    
		     
		    String validationMessage =objCFLogin.getEmail().getAttribute("validationMessage");	
		    String ExpectedValidation= AutomationConstants.TXT1;
		  		
		    Assert.assertEquals(ExpectedValidation,validationMessage);
		    System.out.println("Login Failed, TC_Af_006 Passed");


			  Thread.sleep(2000);
	}
	
	@Test(priority=7)//Verify invalid login with invalid email and invalid password
	public void TC_Af_007_verifyAgentInvalidLogin6() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		    //Create Login Page object
		    objAgent= new Agent(driver);
		    //login to application
		    objCFLogin.clearEmail();
		    String email = ExcelUtility.getCellData(3,1);
		    objCFLogin.clearPassword();
		   String password = ExcelUtility.getCellData(4,1);
		    objCFLogin.setEmail(email);
		  objCFLogin.setPassword(password);
		  
		  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	

		  objCFLogin.clickLogin();
		  
		  Thread.sleep(3000);
		  String expectedURL =AutomationConstants.AFURL13;
		  String actualURL =driver.getCurrentUrl();
		  Assert.assertEquals(expectedURL,actualURL);
		  System.out.println("Login failed,TC_Af_007 passed");
		  Thread.sleep(2000);
		  }
	
		
	@Test(priority=8)
    public void TC_Af_008_verifyAFValidLogin() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
   
    objAgent= new Agent(driver);
        //login to application
    objAgent.clearEmail();
    String email = ExcelUtility.getCellData(1,1);
    objAgent.clearPassword();
   String password = ExcelUtility.getCellData(2,1);
   objAgent.setEmail(email);
   objAgent.setPassword(password);
  
  //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	

   objAgent.clickLogin();
  
  Thread.sleep(4000);
  
      String expectedURL =AutomationConstants.AFURL1;
  String actualURL =driver.getCurrentUrl();
  Assert.assertEquals(expectedURL,actualURL);
  System.out.println("LOGIN Success;Agent Front End Dashboard Opened,TC_Af_008 Passed");
    Thread.sleep(2000);
  }
	
	
	

	@Test(priority=9)
    public void TC_Af_009_verifyagMyBookings() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagMyBookings();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL2;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Bookings Page Opened,TC_Af_009 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	@Test(priority=10)
    public void TC_Af_010_verifyagAddFunds() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagAddFunds();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL3;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Add Funds Page Opened,TC_Af_010 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}	
	
	@Test(priority=11)
    public void TC_Af_011_verifyagMyProfile() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagMyProfile();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL4;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End My Profile Page Opened,TC_Af_011 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	
	@Test(priority=12)
    public void TC_Af_012_verifyaghome() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagHome();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL5;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Home Page Opened,TC_Af_012 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	@Test(priority=13)
    public void TC_Af_014_verifyaghotels() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagHotels();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL6;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Hotels Page Opened,TC_Af_014 Passed");
      Thread.sleep(2000);
 objAgent.clickagHotelscity1();
      Thread.sleep(500);
    
      objAgent.aghotelscity2.sendKeys("Dubai");
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    Thread.sleep(2000);
	    objAgent.SelectCity();
	    Thread.sleep(2000);
      objAgent.ClickSearch();
      Thread.sleep(2000);  
      objAgent.getUrlValue();
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	@Test(priority=14)
    public void TC_Af_016_verifyagFlights() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagFlights();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL7;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Flights Page Opened,TC_Af_016 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	@Test(priority=15)
    public void TC_Af_017_verifyagTours() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagTours();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL8;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Tours Page Opened,TC_Af_017 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	@Test(priority=16)
    public void TC_Af_018_verifyagVisa() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagVisa();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL9;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Visa Page Opened,TC_Af_018 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	@Test(priority=17)
    public void TC_Af_019_verifyagBlogs() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagBlogs();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL10;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Blog Page Opened,TC_Af_019 Passed");
      Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	}
	
	
	@Test(priority=18)
    public void TC_Af_020_verifyagOffers() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagOffers();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    String expectedURL =AutomationConstants.AFURL11;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Agent Front End Offers Page Opened,TC_Af_020 Passed");
      Thread.sleep(2000);
	
	}
	

	@Test(priority=19)
    public void TC_Af_013_verifyagCurrencyConversion() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    
    objAgent.clickagCurrency();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    
    objAgent.clickagINR();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    System.out.println("Currency converted,TC_Af_013 Passed");
   
	Thread.sleep(2000);
	}
	
	@Test(priority=20)
    public void TC_Af_021_verifyagLogout() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
   
    objAgent= new Agent(driver);
    Thread.sleep(2000);
    objAgent.clickagAccounts();
    Thread.sleep(1000);
    objAgent.clickagLogout();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(3000);
    
    String expectedURL =AutomationConstants.AFURL12;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Successfully logged out,TC_Af_021 Passed");
      Thread.sleep(2000);
	
	}		
	
	
	
	}

