package com.tcs.scripts;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariDriver.WindowType;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.tcs.constants.AutomationConstants;
import com.tcs.pages.Admin;
import com.tcs.pages.Agent;
import com.tcs.pages.CFLogin;
import com.tcs.utilities.ExcelUtility;

public class TCAdmin extends TestBase{
	
	CFLogin objCFLogin;
	Admin objAdmin;
	

	@Test(priority=1)
    public void TC_Ad_001_verifyAdminLink() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
    objCFLogin= new CFLogin(driver);
    objAdmin= new Admin(driver);
    objAdmin.clickAdminLink();
    Thread.sleep(2000);
    for(String winHandle :driver.getWindowHandles())
    {
    	driver.switchTo().window(winHandle);
    }
    
    String expectedURL =AutomationConstants.ADURL1;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Admin Back end Login Page Opened,TC_Ad_001 Passed");
      Thread.sleep(2000);   
	}
	
	@Test(priority=2) //Invalid login with both fields blank
    public void TC_Ad_002_verifyAgentInvalidLogin1() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
objAdmin= new Admin(driver);	

objAdmin.clearadEmail();
objAdmin.clearadPassword();
Thread.sleep(2000);   
objAdmin.clickadLogin();
Thread.sleep(4000);
objAdmin.BlankAlertDisplayed();

Thread.sleep(2000);

	}
	@Test(priority=3) //Verify invalid login with valid email and invalid password
    public void TC_Ad_003_verifyADInvalidLogin2() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
    objAdmin= new Admin(driver);
	
  String ademail = ExcelUtility.getCellData(1,2);
    String adpassword = ExcelUtility.getCellData(4,2);
    objAdmin.setadEmail(ademail);
    objAdmin.setadPassword(adpassword);
       objAdmin.clickadLogin();
       Thread.sleep(2000);
       
       objAdmin.BlankAlert3Displayed();

       Thread.sleep(2000);    
	}
	
	
	@Test(priority=4)//Verify invalid login with valid email and null password
	public void TC_Ad_004_verifyADInvalidLogin3() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		    //Create Login Page object
		    objAdmin= new Admin(driver);
			objAdmin.clearadEmail();
		  String ademail = ExcelUtility.getCellData(1,2);
		  objAdmin.setadEmail(ademail);
		  objAdmin.clearadPassword();
		       objAdmin.clickadLogin();
		       Thread.sleep(3000);
	
		       objAdmin.BlankAlert4Displayed();       
		       
		       Thread.sleep(2000);
		   	 
		       
		       
	}
	
	@Test(priority=5)//	Verify invalid login with invalid email and valid password
	
	 public void TC_Ad_005_verifyAdInvalidLogin4() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		    //Create Login Page object
		    objAdmin= new Admin(driver);
		    //login to application
		  
		    objAdmin.clearadEmail();
		    String ademail = ExcelUtility.getCellData(3,2);
		    objAdmin.clearadPassword();
		   String adpassword = ExcelUtility.getCellData(2,2);
		    objAdmin.setadEmail(ademail);
		  objAdmin.setadPassword(adpassword);
		  
		  //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	

		  objAdmin.clickadLogin();
		  Thread.sleep(2000);
		  objAdmin.BlankAlert5Displayed();       
	       
	       Thread.sleep(2000);
	   	 
	
	
	
	}

	@Test(priority=6)//Verify invalid login with blank email and valid password
	
	 public void TC_Ad_006_verifyInvalidLogin5() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		    //Create Login Page object
		    objAdmin= new Admin(driver);
		    
		    objAdmin.clearadEmail();
		    objAdmin.clearadPassword();
		    String adpassword = ExcelUtility.getCellData(2,2);
		    objAdmin.setadPassword(adpassword);
		    objAdmin.clickadLogin();
		    Thread.sleep(2000);
		    objAdmin.BlankAlert6Displayed();       
		       
		       Thread.sleep(2000);
		   	 
	
	
	}
	
	
	@Test(priority=7)//Verify invalid login with invalid email and invalid password
	public void TC_Ad_007_verifyInvalidLogin6() throws IOException, Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		
		 objAdmin= new Admin(driver);
		    //login to application
		  
		    objAdmin.clearadEmail();
		    String ademail = ExcelUtility.getCellData(3,2);
		    objAdmin.clearadPassword();
		   String adpassword = ExcelUtility.getCellData(4,2);
		    objAdmin.setadEmail(ademail);
		  objAdmin.setadPassword(adpassword);
		  
		  //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	

		  objAdmin.clickadLogin();
		  Thread.sleep(2000);
		  objAdmin.BlankAlert7Displayed();       
	       
	       Thread.sleep(2000);
	   	 
	}
		
		
		
		
	@Test(priority=8)
    public void TC_Ad_008_verifyADValidLogin() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
   
    objAdmin= new Admin(driver);
        //login to application
    objAdmin.clearadEmail();
    String ademail = ExcelUtility.getCellData(1,2);
    objAdmin.clearadPassword();
   String adpassword = ExcelUtility.getCellData(2,2);
    objAdmin.setadEmail(ademail);
  objAdmin.setadPassword(adpassword);
  
  //driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	

  objAdmin.clickadLogin();
//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  Thread.sleep(4000);
  
  assertTrue(driver.getTitle().contains("Dashboard"));
  System.out.println("LOGIN Success;Admin Back- End Dashboard Opened,TC_Ad_008 Passed");
    Thread.sleep(2000);
  }
	@Test(priority=9)
    public void TC_Ad_014_verifyADWebsite() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
   
    objAdmin= new Admin(driver);
    Thread.sleep(2000);
    String MainWindow=driver.getWindowHandle();
	objAdmin.clickadWebsite();
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    Thread.sleep(2000);
    for(String winHandle :driver.getWindowHandles())
    {
    	driver.switchTo().window(winHandle);
    }
    
    Thread.sleep(4000);
    String expectedURL =AutomationConstants.ADURL4;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
   // assertTrue(driver.getTitle().contains("JSTRAVELS"));
    System.out.println("Navigated to a different page,TC_Ad_014 Passed");
      Thread.sleep(4000); 
      driver.switchTo().window(MainWindow);
	  driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	  Thread.sleep(3000);
	   
	 String expectedURL2 =AutomationConstants.ADURL2;
	  String actualURL2 =driver.getCurrentUrl();
	  Assert.assertEquals(expectedURL2,actualURL2);
	  System.out.println("Returned to Admin Dashboard");
	    Thread.sleep(2000);
	 
	
	}

	@Test(priority=10)
    public void TC_Ad_009_verifyADBookings() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
   
    objAdmin= new Admin(driver);
    Thread.sleep(2000);
	objAdmin.clickadBooking();
    Thread.sleep(2000);
    String expectedURL =AutomationConstants.ADURL3;
    String actualURL =driver.getCurrentUrl();
    Assert.assertEquals(expectedURL,actualURL);
    System.out.println("Admin Back end Bookings Page Opened,TC_Ad_009 Passed");
      Thread.sleep(2000); 
	}
	
	
	@Test(priority=11)
    public void TC_Ad_012__TC_Ad_013_verifyADPendToConf() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
  
    objAdmin= new Admin(driver);
    Thread.sleep(2000);
    
    objAdmin.getCount();
    int icount=Integer.parseInt(objAdmin.getCount());
    Integer initialcount=Integer.valueOf(objAdmin.getCount());
    System.out.println("InitialCount:"+initialcount);
    Thread.sleep(2000);
	objAdmin.clickadPending();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    objAdmin.clickConfirmed();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    driver.navigate().refresh();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(3000);
    objAdmin.getCount();
    int fcount=Integer.parseInt(objAdmin.getCount());
    Integer finalcount=Integer.valueOf(objAdmin.getCount());
    System.out.println("FinalCount:"+finalcount);
    
    if(fcount>icount) {
    	 System.out.println("Booking Status has been changed from pending to confirmed and number of confirmed booking is incremented; TC_Ad_012,TC_Ad_013 Passed");
    }
    else {
    	System.out.println(" TC_Ad_012 failed");
    }   
	}	
	
	@Test(priority=12)
    public void TC_Ad_010_verifyInvoice() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
    //Create Login Page object
   
    objAdmin= new Admin(driver);
    String MainWindow=driver.getWindowHandle();
    Thread.sleep(2000);
    objAdmin.ViewadUnpaid();
    Thread.sleep(1000);
    objAdmin.clickadUnpaid();
    Thread.sleep(1000);
    objAdmin.clickadPaid();
    Thread.sleep(1000);
   
   // objAdmin.ViewadInvoice();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	objAdmin.clickadInvoice();
    Thread.sleep(4000);
    for(String winHandle :driver.getWindowHandles())
    {
    	driver.switchTo().window(winHandle);
    }
    
    Thread.sleep(3000);
    objAdmin.AssertInvoice();
      Thread.sleep(3000); 
      driver.switchTo().window(MainWindow);
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  Thread.sleep(5000);
	   
	 String expectedURL2 =AutomationConstants.ADURL3;
	  String actualURL2 =driver.getCurrentUrl();
	  Assert.assertEquals(expectedURL2,actualURL2);
	  System.out.println("Returned to booking page");
	    Thread.sleep(2000);  
      
	}
	
	@Test(priority=13)
    public void TC_Ad_011_verifyADDeleteBooking() throws IOException, Exception {
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
  
    objAdmin= new Admin(driver);
    Thread.sleep(2000);
    objAdmin.ViewadConfirmed2();
    objAdmin.clickadConfirmed2();
    Thread.sleep(500);
    objAdmin.clickaCancelled();
    Thread.sleep(500);
	objAdmin.clickadDelete();
	Thread.sleep(500);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    Thread.sleep(2000);
    objAdmin.acceptAlert();
    Thread.sleep(2000);
    System.out.println("TC_Ad_011 passed");
    Thread.sleep(2000);
	
	}	
	
}
